<?php
    $nama = $_SESSION['user']['nama_user'];

?>
<p class="welcome">
    Selamat Datang BOSSSS <?= $nama; ?>
</p>