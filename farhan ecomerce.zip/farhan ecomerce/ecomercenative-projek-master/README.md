
# E- Commerce
E-Commerce memudahkan penjualan



## Authors

- [Nanang Setiawan](https://github.com/livingdolls/)


## 🚀 About Me
I'm a full stack developer and i think im funny


## Features

- Manajemen Barang
- Manajemen User
- Manajemen Kategori
- Manajemen Pembayaran
- Detail Produk
- Pencarian Produk
- Pembayaran
- Multi role admin dan User
- ETC
## Tech Stack

**Client:** Bootstrap, CSS

**Server:** PHP, MySql


## Screenshots

![alt text](https://raw.githubusercontent.com/livingdolls/ecomercenative-projek/master/img/ecommerce.png)
## License

[MIT](https://choosealicense.com/licenses/mit/)
